package com.example.contador

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var contador = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Obtener referencias a las vistas
        val tvContador = findViewById<TextView>(R.id.tvContador)
        val btnIncrementar = findViewById<Button>(R.id.btnIncrementar)
        val btnDecrementar = findViewById<Button>(R.id.btnDecrementar)
        val btnReset = findViewById<Button>(R.id.btnReset)

        // Inicializar el texto del contador
        tvContador.text = contador.toString()

        // Botón incrementar
        btnIncrementar.setOnClickListener {
            contador++
            tvContador.text = contador.toString()
        }

        // Botón decrementar
        btnDecrementar.setOnClickListener {
            contador--
            tvContador.text = contador.toString()
        }

        // Botón reset
        btnReset.setOnClickListener {
            contador = 0
            tvContador.text = contador.toString()
        }
    }
}
